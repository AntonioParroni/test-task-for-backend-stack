CREATE VIEW QuantityOfTheDevicesPerMonth AS
    SELECT ByMonth.Year, ByMonth.Month, DT.DeviceName, ByYear.NumberOfUsers FROM RegistrationCountByMonth ByMonth
    INNER JOIN RegistrationCountByDevicesAndMonth ByYear ON ByMonth.Month = ByYear.Month AND ByMonth.Year = ByYear.Year
    INNER JOIN DeviceTypes DT on DT.DeviceID = ByYear.DeviceType
    WITH CHECK OPTION
go

